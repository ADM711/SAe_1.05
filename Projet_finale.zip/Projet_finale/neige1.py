import csv
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter import filedialog


table = []
période = []
ville1 = set()  


def charger_donnees():
    global table, ville1
    fichiers = filedialog.askopenfilenames(
        title="Sélectionnez les fichiers CSV",
        filetypes=[("Fichiers CSV", "*.csv")]
    )
    if not fichiers:
        messagebox.showerror("Erreur", "Aucun fichier sélectionné.")
        return

    table.clear()
    ville1.clear()

    for fichier in fichiers:
        try:
            with open(fichier, newline='', encoding='utf-8') as csvfile:
                reader = csv.reader(csvfile, delimiter=';')
                for row in reader:
                    table.append(row)
                    if len(row) > 1:  
                        ville1.add(row[1].lower())
        except Exception as e:
            messagebox.showerror("Erreur", f"Impossible de lire {fichier}: {str(e)}")

    ville_combobox['values'] = sorted(ville1)
    messagebox.showinfo("Chargement réussi", "Les données ont été chargées avec succès!")


def afficher_graphique():
    global période
    ville = ville_combobox.get().lower()
    datemin = datemin_entry.get()
    datemax = datemax_entry.get()

    if not ville or not datemin or not datemax:
        messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
        return
    if ville not in ville1:
        messagebox.showerror("Erreur", f"La ville '{ville}' n'est pas valide. Sélectionnez une ville dans la liste ou entrez une ville valide.")
        return

    période = []
    for row in table:
        if len(row) > 50 and row[1].lower() == ville and datemin <= row[5] <= datemax:
            try:
                hauteur_neige = float(row[50]) if row[50].strip() else None
                if hauteur_neige is not None:
                    période.append((row[5], hauteur_neige))
            except ValueError:
                continue

    if période:
        période.sort(key=lambda x: x[0])
        dates = [item[0] for item in période]
        hauteurs = [item[1] for item in période]
        step = max(1, len(dates) // 10)  
        affichage_dates = [dates[i] for i in range(0, len(dates), step)]

        
        plt.figure(figsize=(10, 6))
        plt.plot(dates, hauteurs, marker='o', label="Hauteur de neige")
        plt.title(f"Évolution de la hauteur de neige à {ville} entre {datemin} et {datemax}")
        plt.xlabel("Date")
        plt.ylabel("Hauteur de neige (cm)")
        plt.xticks(ticks=range(0, len(dates), step), labels=affichage_dates, rotation=45, fontsize=8)
        plt.grid(True, linestyle='--', alpha=0.6)
        plt.legend()
        plt.tight_layout()  
        plt.show()
    else:
        messagebox.showinfo("Aucune donnée", f"Aucune donnée trouvée pour {ville} entre {datemin} et {datemax}.")


def zones_les_plus_enneigees():
    if not table:
        messagebox.showerror("Erreur", "Aucune donnée chargée. Veuillez charger les fichiers CSV d'abord.")
        return

    neige_par_ville = {}
    for row in table:
        if len(row) > 50:
            try:
                ville = row[1].lower()
                hauteur_neige = float(row[50]) if row[50].strip() else 0
                if ville in neige_par_ville:
                    neige_par_ville[ville].append(hauteur_neige)
                else:
                    neige_par_ville[ville] = [hauteur_neige]
            except ValueError:
                continue

    villes_avec_stats = []
    for ville, hauteurs in neige_par_ville.items():
        totale = sum(hauteurs)
        moyenne = totale / len(hauteurs)
        maximale = max(hauteurs)
        villes_avec_stats.append((ville, totale, moyenne, maximale))    
    villes_avec_stats.sort(key=lambda x: x[3], reverse=True)
    resultats = "Zones les plus enneigées (basées sur la hauteur maximale de neige) :\n"
    for i, (ville, totale, moyenne, maximale) in enumerate(villes_avec_stats[:5]):
        resultats += f"{i+1}. {ville.capitalize()} - Max : {maximale} cm, Moyenne : {moyenne:.2f} cm, Total : {totale:.2f} cm\n"

    messagebox.showinfo("Zones les plus enneigées", resultats)


root = tk.Tk()
root.title("Analyse de la hauteur de neige")
file_frame = tk.Frame(root)
file_frame.pack(pady=10)
load_button = tk.Button(file_frame, text="Charger les fichiers CSV", command=charger_donnees)
load_button.pack()
ville_frame = tk.Frame(root)
ville_frame.pack(pady=10)
tk.Label(ville_frame, text="Choisissez ou entrez une ville :").pack(side=tk.LEFT)
ville_combobox = ttk.Combobox(ville_frame, width=30)
ville_combobox.pack(side=tk.LEFT)
date_frame = tk.Frame(root)
date_frame.pack(pady=10)
tk.Label(date_frame, text="Date de départ (aaaammjj) :").grid(row=0, column=0, padx=5, pady=5)
datemin_entry = tk.Entry(date_frame, width=15)
datemin_entry.grid(row=0, column=1, padx=5, pady=5)
tk.Label(date_frame, text="Date limite (aaaammjj) :").grid(row=1, column=0, padx=5, pady=5)
datemax_entry = tk.Entry(date_frame, width=15)
datemax_entry.grid(row=1, column=1, padx=5, pady=5)
graph_button = tk.Button(root, text="Afficher le graphique", command=afficher_graphique)
graph_button.pack(pady=10)
zones_button = tk.Button(root, text="Zones les plus enneigées", command=zones_les_plus_enneigees)
zones_button.pack(pady=10)
root.mainloop()















